#!/bin/bash

# File to watch
WATCH_FILE="/home/student"
USER="student"

# Generate a random password
generate_random_password() {
    tr -dc A-Za-z0-9 </dev/urandom | head -c 12 ; echo ''
}

# Monitor the file for deletion
while true; do
(inotifywait -e delete "$WATCH_FILE" | grep "DELETE getflag" ) &&
{
    # Change the user's password to a random value
    NEW_PASSWORD=$(generate_random_password)
    echo "$USER:$NEW_PASSWORD" | sudo chpasswd

    touch PTITD20

    # Terminate all SSH sessions for the user
    pkill -u "$USER" sshd

    echo "SSH sessions terminated and password changed for user $USER"
}
	sleep 1
done
