#!/bin/bash

service ssh start
service apache2 start
/bin/bash /home/student/watch_file.sh

#exec /usr/sbin/sshd -D

